
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from space_game.middleware import PreserveJSONResponse, json_to_html


app = FastAPI(default_response_class=PreserveJSONResponse)

# register middleware that automatically uses JINJA templates
# so we only have to write REST functions
# *** Kudos to Tim Weber for finding out! ***
app.middleware("http")(json_to_html)



class GameData(BaseModel):

    planet: str
    image: str
    description: str
    cargo: str|None = None
    crew: list[str] = ["panda"]
    commands: list[str]
    message: str|None = None



@app.get("/new_game", response_model=GameData)
def new_game() -> GameData:
    return GameData(
        planet="Pandalor",
        image="pandalor",
        description="a thick bamboo forest",
        cargo="bamboo",
        commands=["one", "two", "three"],
    )


@app.get("/action/{command}")
def action(command: str) -> GameData:
    return GameData(
        planet="Turing",
        image="turing",
        description="a thick bamboo forest",
        cargo="minerals",
        crew=["panda", "python"],
        commands=["one", "two", "three"],
    )



# Also let FastAPI serve the HTMX "frontend" of our application.
app.mount("/", StaticFiles(directory="static", html=True), name="static")
